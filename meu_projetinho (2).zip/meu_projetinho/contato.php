<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style_contato.css">
    <title>Formulário de Contato</title>
    <style>
        body {
    font-family: Arial, sans-serif;
    background-color: #000000;
    margin: 0;
    padding: 20px;
}

.container {
    position: absolute;
    top: 40px;
    right: 400px;
    max-width: 600px;
    margin: 0 auto;
    background: #ffffff;
    padding: 20px 90px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    border-radius: 8px;
}

h1 {
    text-align: center;
    color: #333333;
}

form {
    display: flex;
    flex-direction: column;
}

label {
    margin-bottom: 5px;
    font-weight: bold;
}

input, textarea {
    margin-bottom: 15px;
    padding: 10px 100px;
    border: 1px solid #cccccc;
    border-radius: 4px;
    font-size: 16px;
}

textarea {
    resize: vertical;
    min-height: 100px;
    text-align: left; /* Alinha o texto à esquerda */
    vertical-align: top; /* Alinha o texto ao topo */
    margin-bottom: 15px;
    padding: 10px; /* Garantir espaço interno consistente */
    border: 1px solid #cccccc;
    border-radius: 4px;
    font-size: 16px;
}

button {
    background-color: #2a28a7;
    color: #ffffff;
    border: none;
    padding: 10px 20px;
    font-size: 16px;
    border-radius: 4px;
    cursor: pointer;
    text-align: center;
}

button:hover {
    background-color: #1f1d85;
}
    </style>
</head>
<body>
    <div class="container">
        <h1>Entre em Contato</h1>
        <form action="processar_formulario.php" method="POST">
            <label for="nome">Nome:</label>
            <input type="text" id="nome" name="nome" placeholder="Seu nome" required>

            <label for="email">E-mail:</label>
            <input type="email" id="email" name="email" placeholder="Seu e-mail" required>

            <label for="mensagem">Qual é o problema?</label>
            <textarea id="mensagem" name="mensagem" placeholder="Descreva o problema" required></textarea>

            <button type="submit">Enviar</button>
        </form>
    </div>
</body>
</html>
