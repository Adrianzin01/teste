<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style_termos.css">
    <title>Política e Privacidade</title>
    <Style>
        body {
    font-family: Arial, sans-serif;
    line-height: 1.6;
    margin: 0;
    padding: 0;
    background-color: #cacaca;
}
header {
    background-color: #333;
    color: #fff;
    padding: 1rem 0;
    text-align: center;
}
nav ul {
    list-style: none;
    padding: 0;
    margin: 0;
}

nav ul li {
    display: inline;
    margin: 0 15px;
}

nav ul li a {
    color: #fff;
    text-decoration: none;
    font-weight: bold;
}

main {
    max-width: 800px;
    margin: 20px auto;
    background: white;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

h1 {
    text-align: center;
    color: aliceblue;
    font-size: 2rem;
}

section {
    margin-bottom: 20px;
}

a {
    transition: color 0.3s ease;
    text-decoration: none;
    color: #ffffff;
}
a:hover {
    color: #ff5733; /* Cor do link ao passar o mouse */
}

a:hover {
    color: #0400ff; /* Alterna para outra cor */
}

footer {
    padding: 10px 0;
    background: #333;
    color: #fff;
    text-align: center;
    margin-top: 20px;
}
    </Style>
</head>
<body>
    <header>
        <h1>Termos de Serviço</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="contato.php">Contato</a></li>
                <li><a href="termos_de_servico.php">Termos de Serviço</a></li>
                <li><a href="politica_privacidade.php">Política de Privacidade</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <section class="copyright">
            <h2>Copyright</h2>
            <p>© 2024 Valve Corporation. Todos os direitos reservados. Valve, a logomarca Valve, Half-Life, a logomarca Half-Life, a logomarca Lambda, Steam, a logomarca Steam, Team Fortress, a logomarca Team Fortress, Opposing Force, Day of Defeat, a logomarca Day of Defeat, Counter-Strike, a logomarca Counter-Strike, Source, a logomarca Source, Counter-Strike: Condition Zero, Portal, a logomarca Portal, Dota, a logomarca Dota 2 e Defense of the Ancients são marcas comerciais e/ou marcas comercias registradas da Valve Corporation. Todas as outras marcas comerciais são propriedade de seus respectivos donos.</p>
        </section>

        <section class="valve-policy">
            <h2>Política dos Termos da Valve</h2>
            <h3><a href="https://store.steampowered.com/subscriber_agreement/?l=brazilian" target="_blank">Clique aqui para mais informações</a></h3>
        </section>

        <section class="third-party-notices">
            <h2>Avisos Legais de Terceiros</h2>
            <p>O Steam e outros produtos da Valve distribuídos pelo Steam usam alguns materiais de terceiros que exigem notificações sobre seus termos de licença. Você pode encontrar uma lista dessas notificações no arquivo chamado ThirdPartyLegalNotices.doc distribuído com o cliente do Steam e/ou com um produto específico da Valve. Quando os termos da licença exigirem que a Valve disponibilize o código-fonte para redistribuição, esse código estará aqui. Alguns dados geoespaciais neste site são fornecidos por geonames.org</p>
        </section>

        <section class="copyright-claims">
            <h2>Alegações de Violação de Direito Autoral</h2>
            <p>A Valve respeita os direitos de propriedade intelectual alheios, por isso solicitamos que todos que usam nossos sites e serviços na internet façam o mesmo. Qualquer pessoa que acreditar que seu trabalho tenha sido reproduzido em um de nossos sites ou serviços na internet de uma forma que configure uma violação de direito autoral pode notificar a Valve por esta página.</p>
        </section>
    </main>
    <footer>
        <center><p>&copy; 2024 Paradise Game. Todos os direitos reservados. Todas as marcas são propriedade dos seus respectivos donos nos EUA e em outros países. <br>
            IVA incluso em todos os preços onde aplicável. <a href="politica_privacidade.php">Política de Privacidade</a>   | <a href="index.php">Home</a>  | <a href="contato.php">Contato</a>   
            </p></center>
    </footer>
</body>
</html>
