<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style_privacidade.css">
    <title>Política e Privacidade</title>
    <style>
        body {
    font-family: Arial, sans-serif;
    line-height: 1.6;
    margin: 0;
    padding: 0;
    background-color: #bbbbbb;
}
header {
    background-color: #333;
    color: rgb(255, 255, 255);
    padding: 1rem 0;
}
nav ul {
    text-align: center;
    list-style: none;
    padding: 0;
    margin: 10px 0;
}

nav ul li {
    display: inline;
    margin-right: 15px;
}

nav ul li a {
    color: #fff;
    text-decoration: none;
}
main {
    max-width: 800px;
    margin: 20px auto;
    background: white;
    padding: 20px;
    border-radius: 5px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}
h1{
    text-align: center;
    color: aliceblue;
}
h2 {
    color: #000000;
}
p {
    line-height: 100%;
    margin: 10px 0;
}
footer {
    padding: 10px 0;
    background: #333;
    color: rgb(255, 255, 255);
    margin-top: 20px;
}
a {
    transition: color 0.5s ease;
    text-decoration: none;
    color: #ffffff;
}
a:hover {
    color: #ff5733; /* Cor do link ao passar o mouse */
}

a:hover {
    color: #0400ff; /* Alterna para outra cor */
}
    </style>
<body>
    <header>
        <h1>Acordo de Política e Privacidade</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="contato.php">Contato</a></li>
                <li><a href="termos_de_servico.php">Termos de Serviço</a></li>
                <li><a href="politica_privacidade.php">Política de privacidade</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <h2>Política de Privacidade</h2>
        <div>
            <span style="white-space: pre-line">
                A Valve respeita a privacidade dos seus visitantes on-line e dos clientes dos seus produtos e serviços e está em conformidade com as leis aplicáveis de proteção de privacidade, incluindo, sem limitação, a Lei de Privacidade do Consumidor da Califórnia ("CCPA"), o Regulamento Geral sobre a Proteção de Dados da União Europeia ("GDPR”) e o Regulamento Geral sobre a Proteção de Dados do Reino Unido.
                
                A Valve e sua subsidiária, TR Technical Inc., agem em concordância com a Estrutura de Privacidade de Dados UE-EUA (EU-U.S. DPF), a Extensão do RU da EU-U.S. DPF e a Estrutura de Privacidade de Dados Suíça-EUA (Swiss-U.S. DPF), conforme estabelecido pelo Departamento de Comércio dos EUA. A Valve confirmou ao Departamento de Comércio dos EUA sua adesão aos Princípios da Estrutura de Privacidade de Dados UE-EUA (Princípios da EU-U.S. DPF) no que diz respeito ao processamento de dados pessoais recebidos da União Europeia em conformidade com a EU-U.S. DPF e do Reino Unido (e Gibraltar) em conformidade com a Extensão do RU da EU-U.S. DPF. A Valve confirmou a Departamento de Comércio dos EUA sua adesão aos Princípios da Estrutura de Privacidade de Dados Suíça-EUA (Princípios da Swiss-U.S. DPF) no que diz respeito ao processamento de dados pessoais recebidos da Suíça em conformidade com a Swiss-U.S. DPF. Em caso de qualquer conflito entre os termos desta política de privacidade e os Princípios da EU-U.S. DPF e/ou os Princípios da Swiss-U.S. DPF, prevalecerão os Princípios. Caso queira saber mais sobre o programa da Estrutura de Privacidade de Dados (DPF), e para consultar a nossa certificação, visite https://www.dataprivacyframework.gov/.
                
                1. Definições
                
                Quando falamos sobre dados pessoais ("Dados Pessoais") abaixo, queremos dizer qualquer informação que possa identificar você como um indivíduo ("Informações de Identificação Pessoal") ou que possa ser associada a você indiretamente, vinculando-o às Informações de Identificação Pessoal. A Valve também processa dados anônimos, agregados ou não, com o intuito de analisar e produzir dados estatísticos relacionados aos hábitos, padrões de uso e dados demográficos de usuários como um grupo ou como indivíduos. Tais dados anônimos não permitem a identificação dos clientes aos quais são relacionados. A Valve pode compartilhar dados anônimos, agregados ou não, com terceiros.
                
                Outros termos capitalizados na presente Política de Privacidade tem o significado definido no Acordo de Assinatura do Steam (ou Steam Subscriber Agreement, "SSA").
                
                2. Por que a Valve coleta e processa dados
                
                A Valve coleta e processa Dados Pessoais pelas seguintes razões:
                
                2.1 quando for necessário para o desempenho do nosso acordo com você para fornecer um serviço de jogos completo e proporcionar Conteúdo e Serviços associados;
                2.2 quando for necessário para o cumprimento das obrigações legais a que estamos sujeitos (por exemplo, obrigações para reter determinadas informações nos termos da legislação fiscal);
                2.3 quando for necessário para os efeitos de interesse legítimo e legal da Valve ou de terceiros (por exemplo, interesses dos nossos outros clientes), exceto quando esses interesses não prevaleçam sobre seus interesses e direitos legítimos; ou
                2.4 quando você der consentimento para isso.
                
                Essas razões para a coleta e processamento de Dados Pessoais determinam e limitam quais Dados Pessoais coletamos e como eles serão usados (seção 3 abaixo), por quanto tempo nós os armazenamos (seção 4 abaixo), quem tem acesso a ele (seção 5 abaixo) e quais direitos e outros mecanismos de controle estão disponíveis a você como usuário (seção 6 abaixo).
                
                3. Os tipos e fontes de dados que coletamos
                
                3.1 Dados básicos da conta
                Ao configurar uma Conta, a Valve coletará seu endereço de e-mail e o país de residência. Você também precisa escolher um nome de usuário e uma senha. Essa informação é necessária para registrar uma Conta de Usuário do Steam. Durante a configuração da sua conta, um número (o "Steam ID") é atribuído automaticamente à conta. Ele é usado para se referir à sua conta de usuário sem expor suas Informações de Identificação Pessoal.
                Não pedimos que você forneça nem use seu nome verdadeiro para a configuração de uma Conta de Usuário do Steam.
                
                3.2 Dados de pagamento e transação
                Para fazer uma transação no Steam (por exemplo, comprar Assinaturas de Conteúdo e Serviços ou enviar fundos para sua Carteira Steam), você precisará fornecer à Valve os dados do pagamento. Se você pagar com cartão de crédito, será preciso fornecer as informações típicas de cartão de crédito (nome, endereço, número do cartão de crédito, data de validade e código de segurança) à Valve, que processará e transmitirá os dados para o provedor de serviços de sua escolha a fim de permitir a operação e executar controles antifraude. Pelas mesmas razões citadas acima, a Valve também receberá dados do seu provedor de serviços de pagamento.
                
                3.3 Outros dados enviados explicitamente pelo usuário
                Coletaremos e processaremos os Dados Pessoais sempre que você fornecê-los ou enviá-los explicitamente como parte da comunicação com terceiros no Steam, por exemplo, nos Fóruns da Comunidade do Steam ou nos bate-papos, ou quando você enviar feedback ou outro conteúdo gerado pelo usuário. Esses dados incluem:<br>
                <p>°Informações que você publica, comenta ou segue nos nossos Conteúdos e Serviços;<br>
                °Informações enviadas por meio de bate-papo;<br>
                °Informações que você fornece ao solicitar informações ou suporte à nossa equipe ou ao adquirir Conteúdo e Serviços, incluindo as informações necessárias para processar seus pedidos junto ao provedor de pagamentos correspondente ou, em caso de bens físicos, transportadoras;<br>
                °Informações que você nos fornece ao participar de concursos, competições e torneios ou quando responde a pesquisas, por exemplo, seus detalhes de contato.<br></p>
                3.4 Seu uso do cliente e de sites do Steam
                Nós coletamos uma variedade de informações por meio da sua interação geral com os sites, o Conteúdo e os Serviços oferecidos pelo Steam. Os Dados Pessoais que coletamos podem incluir, mas sem limitação, informações do navegador e do dispositivo, dados coletados por meio de interações eletrônicas automatizadas e dados de uso de aplicativos.
                Da mesma forma, acompanharemos nossa atividade nos sites e aplicativos para verificar que você não é um bot e para otimizar nossos serviços.
                
                3.5 Seu uso dos jogos e outras assinaturas
                A fim de fornecer esses serviços a você, precisamos coletar, armazenar e utilizar várias informações sobre sua atividade no nosso Conteúdo e em nossos Serviços. "Informações Relacionadas ao Conteúdo" inclui seu Steam ID e as "estatísticas de jogo". "Estatísticas de jogo" significa informações sobre suas preferências e o progresso nos jogos e o tempo de uso, bem como informações sobre o dispositivo que você está usando, incluindo sistema operacional, configurações, identificadores únicos de dispositivos e dados de falha.
                
                3.6 Dados de rastreamento e cookies
                Utilizamos "Cookies", que são arquivos de texto adicionados ao seu computador, e tecnologias semelhantes (por exemplo, "web beacons", pixels, tags de anúncios e identificadores de dispositivo) para nos ajudar a analisar como os usuários usam nossos serviços e também para melhorar os serviços que oferecemos e o recurso de marketing, de análise ou do site. O uso de cookies é padrão na internet. Embora a maioria dos navegadores da Web aceite cookies automaticamente, a decisão de autorizar ou negar é sua. Você pode ajustar as configurações do seu navegador para impedir o recebimento de cookies ou para enviar uma notificação sempre que um cookie for recebido no seu computador.
                Você pode gerenciar o uso de cookies opcionais clicando na página "Configurações de Cookies", acessível a partir do banner que aparece quando você visita nosso site pela primeira vez, ou a qualquer momento através da página de Configurações de Cookies disponível aqui.
                Quando você acessa qualquer um dos nossos serviços, nossos servidores registram seu endereço IP, que é um número atribuído automaticamente à rede a qual seu computador faz parte.
                
                3.7 Recomendações de conteúdo
                Podemos processar informações coletadas nos termos desta seção 3, de modo que o conteúdo, os produtos e os serviços mostrados nas páginas da loja do Steam e nas mensagens de atualização exibidas ao iniciar o cliente do Steam podem ser adaptados para atender às suas necessidades e preenchidos com recomendações e ofertas relevantes. Isto é feito para melhorar a experiência do seu cliente. Você pode impedir o processamento dos seus dados dessa forma ao desligar o carregamento automático da página da loja do Steam e das notificações do Steam na seção "Interface" das configurações do cliente do Steam.
                A Valve pode enviar mensagens de marketing ao seu endereço de e-mail (ou onde você deu consentimento explícito) sobre produtos e serviços similares aos produtos e serviços que você solicitou à Valve anteriormente. Nesse caso, poderemos utilizar também suas informações coletadas para personalizar essas mensagens de marketing, além de coletar informações das suas ações, como se você abriu essas mensagens e em que links do texto delas você clicou.
                Você pode cancelar ou revogar seu consentimento de receber e-mails de marketing a qualquer momento, ao revogar seu consentimento na mesma página onde você tinha previamente concedido ou ao clicar no link "cancelar inscrição" incluído em cada e-mail de marketing. Como alternativa, é possível selecionar os tipos de e-mail que você deseja receber na página de configuração de e-mails.
                
                3.8 Informações necessárias para detecção de violações
                Nós coletamos alguns dados que são necessários para a detecção, investigação e prevenção de fraude e outras violações do SSA e da legislação aplicável ("Violações"). Esses dados são usados apenas para fins de detecção, investigação, prevenção e, quando aplicável, tomada de medidas contra tais violações. Eles são armazenados somente para o tempo mínimo necessário para essa finalidade. Se os dados indicarem que uma Violação ocorreu, continuaremos a armazená-los para a definição, o exercício ou a defesa de reivindicações legais aplicáveis durante o estatuto de limitações ou até que um caso judicial relacionado a ela tenha sido resolvido. Observe que os dados armazenados específicos para essa finalidade não podem ser divulgados a você se a divulgação comprometer o mecanismo por meio do qual podemos detectar, investigar e evitar tais Violações.
                
                4. Por quanto tempo os dados são armazenados
                
                Armazenaremos informações apenas pelo tempo necessário para cumprir as finalidades para as quais as informações são coletadas e processadas ou — nos casos em que a legislação aplicável prevê um período de armazenamento e retenção mais longo — pelo tempo exigido por lei. Depois disso, seus Dados Pessoais serão apagados, bloqueados ou anonimizados, como previsto pela legislação aplicável.
                
                Em especial:
              °  Se você encerrar a sua Conta de Usuário do Steam, seus Dados Pessoais serão marcados para exclusão, exceto se os requisitos legais ou outros fins legítimos prevalecentes solicitarem um período de armazenamento mais longo.
              °  Em certos casos, os Dados Pessoais não podem ser completamente eliminados, a fim de garantir a consistência da experiência do jogo ou do Mercado da Comunidade do Steam. Por exemplo, partidas que afetam outros dados e pontuações de partidas de outros jogados não serão removidos. Em vez disso, sua conexão com estes jogos será permanentemente anonimizada.
              °  Observe que a Valve é obrigada a manter certos dados transacionais nos termos da legislação fiscal e comercial estatutária por um período de até 10 (dez) anos.
              °  Se você remover sua autorização quanto ao processamento dos seus Dados Pessoais ou dos Dados Pessoais do seu filho, excluiremos seus Dados Pessoais ou os do seu filho imediatamente, desde que a coleta e o processamento sejam dependentes dessa autorização.
              °  Se você se opuser ao processamento dos seus Dados Pessoais, sua objeção será analisada e removeremos imediatamente os Dados Pessoais que forem usados para a finalidade à qual você se opôs, a menos que haja outra base jurídica para o processamento e a retenção de dados ou se a legislação aplicável exigir a retenção deles.
                
                5. Quem tem acesso aos dados
                
                A Valve não vende Dados Pessoais. No entanto, podemos compartilhar ou fornecer acesso a cada uma das categorias de Dados Pessoais que coletamos, conforme necessário, para os seguintes fins comerciais.
                
                5.1 A Valve e suas subsidiárias podem compartilhar seus Dados Pessoais entre elas e usá-los para as finalidades listadas na seção 2 acima. No caso de uma reorganização, fusão ou venda, poderemos transferir os Dados Pessoais aos terceiros relevantes, sujeito à legislação aplicável, aos princípios e aos requisitos de conformidade com a DPF.
                
                5.2 Também podemos compartilhar seus Dados Pessoais com nossos fornecedores de serviços terceirizados que prestam os serviços de suporte ao cliente em relação a mercadorias, Conteúdo e Serviços distribuídos por meio do Steam. Seus Dados Pessoais serão utilizados em conformidade com esta Política de Privacidade e apenas na medida necessária para a prestação dos serviços de suporte ao cliente. A Valve segue os Princípios em todas as transferências de Dados Pessoais a partir da UE, da Suíça e do Reino Unido, incluindo as disposições que regem a conformidade da transferência.
                
                5.3 De acordo com padrões da Internet, também podemos compartilhar determinadas informações (incluindo seu endereço IP e a identificação do conteúdo do Steam que você deseja acessar) com nossos provedores de rede terceirizados que prestam serviços de rede de distribuição de conteúdo e de servidores de jogos com relação ao Steam. Nossos provedores de rede de distribuição de conteúdo permitem a entrega do conteúdo digital que você solicitou ao usar o Steam, por exemplo, por meio de um sistema de servidores distribuídos que envia o conteúdo com base na sua localização geográfica.
                
                5.4 Disponibilizamos alguns dados relacionados à sua Conta de Usuário do Steam para outros jogadores e nossos parceiros por meio da Steamworks API. Essas informações podem ser acessadas por qualquer pessoa ao pesquisar seu Steam ID. Pelo menos, o nome público que você escolheu para representá-lo no Steam e a imagem do seu Avatar são acessíveis dessa forma. Ao verificar seu Steam ID, também é possível saber se você recebeu um banimento por trapacear em um jogo multijogador. A disponibilização de qualquer informação adicional sobre você pode ser controlada na sua página de perfil do usuário da Comunidade do Steam. Os dados disponíveis publicamente na sua página de perfil podem ser acessados automaticamente por meio da Steamworks API. Além das informações disponíveis ao público, desenvolvedores de jogos e editores têm acesso a determinadas informações da Steamworks API diretamente relacionadas aos usuários de jogos que eles operam. Essas informações incluem, no mínimo, sua propriedade do jogo em questão. Dependendo de quais serviços da Steamworks API são implementados no jogo, ele também pode incluir informações de liderança, seu progresso no jogo, suas conquistas, suas informações de placar de jogo multijogador, itens de jogo e outras informações necessárias para o funcionamento do jogo e o suporte a ele. Para mais informações sobre quais serviços da Steamworks API foram implementados em um jogo específico, consulte a página da loja que o forneceu.
                Embora não compartilhemos Informações de Identificação Pessoal sobre você na Steamworks API como seu nome real ou seu endereço de e-mail, todas as informações que você compartilhar sobre si mesmo no seu perfil do Steam podem ser acessadas por meio da Steamworks API, incluindo informações que podem identificá-lo.
                
                5.5 A comunidade do Steam inclui painéis de mensagens, fóruns e/ou áreas de bate-papo, onde os usuários podem trocar ideias e se comunicar uns com os outros. Ao publicar uma mensagem em um painel, fórum ou bate-papo, lembre-se de que as informações estão sendo disponibilizadas ao público na Internet. Portanto, você está fazendo isso por sua conta e risco. Se seus Dados Pessoais forem publicados em um dos fóruns da nossa comunidade contra a sua vontade, use a função de denúncia e o site de ajuda do Steam para solicitar a remoção dos dados.
                
                5.6 A Valve pode permitir que você vincule sua conta de usuário do Steam a uma conta oferecida por terceiros. Se você concordar em vincular as contas, a Valve pode coletar e combinar informações que você permitiu que a Valve receba de terceiros com informações da sua conta de usuário do Steam na medida permitida pelo seu consentimento no momento. Se o vínculo das contas exigir a transmissão de informações sobre a sua pessoa da Valve a terceiros, você será informado sobre isso antes de as contas serem vinculadas e terá a oportunidade de aceitar o vínculo e a transmissão de suas informações. O uso das suas informações por terceiros estará sujeito à política de privacidade do terceiro, que incentivamos você a revisar.
                
                5.7 A Valve pode divulgar Dados Pessoais para cumprir ordens judiciais ou leis e regulamentações que nos obriguem a fazê-lo.
                
                6. Seus direitos e mecanismos de controle
                
                As leis de proteção de dados do Espaço Econômico Europeu, do Reino Unido, da Califórnia e de outros territórios concedem aos seus residentes determinados direitos em relação aos Dados Pessoais. Embora outras jurisdições forneçam menos direitos, criamos ferramentas para que os clientes de todo o mundo possam exercê-los. (Quando falamos sobre o GDPR nesta seção, queremos dizer a versão do GDPR que se aplica a você na UE ou no Reino Unido).
                
                Para que você possa exercer seu direito à proteção de dados de forma simples, disponibilizamos uma seção dedicada na página de suporte do Steam (o "Painel de privacidade"). Ela oferece acesso aos seus Dados Pessoais, permite corrigi-los e excluí-los e se opor ao uso deles, quando necessário. Para acessá-la, faça o login na página de suporte do Steam em https://help.steampowered.com e escolha os itens do menu Minha conta -> Dados relacionados à sua conta Steam. Na maioria dos casos, você pode acessar, gerenciar ou excluir Dados Pessoais no Painel de Privacidade, mas também pode entrar em contato com a Valve com perguntas ou solicitações por meio dos processos de contato descritos nas seções 8 e 10 abaixo.
                
                Como visitante do site do Steam sem estar conectado, você pode controlar os Cookies por meio do processo descrito na seção 3.6 acima. Você também pode entrar em contato com a Valve ou seu representante europeu por meio das informações de contato fornecidas na seção 8. abaixo para exercer seus direitos ou usar este formulário.
                
                Como residente do Espaço Econômico Europeu ou do Reino Unido, você tem os seguintes direitos quanto aos seus Dados Pessoais:
                
                6.1 Direito de acesso
                Você tem o direito de acessar os Dados Pessoais que mantemos sobre você, ou seja, o direito de solicitar gratuitamente (i) informações se os seus Dados Pessoais estão armazenados, (ii) o acesso aos Dados Pessoais armazenados e/ou (iii) cópias dos Dados Pessoais armazenados. Você pode exercer o direito de acesso aos seus Dados Pessoais por meio do Painel de Privacidade. Se a solicitação afetar os direitos e as liberdades de terceiros ou for infundada ou excessiva, reservamo-nos o direito de cobrar uma taxa razoável (levando em conta os custos administrativos de fornecer as informações ou a comunicação ou efetuar a ação solicitada) ou de recusar a solicitação.
                
                6.2 Direito de retificação
                Se processarmos seus Dados Pessoais, nós asseguraremos a implementação de medidas adequadas para que eles se mantenham atualizados e precisos de acordo com as finalidades para que foram coletados. Se seus Dados Pessoais estiverem imprecisos ou incompletos, você pode alterar as informações fornecidas no Painel de Privacidade.
                
                6.3 Direito de remoção
                Você tem o direito de obter a exclusão de Dados Pessoais relacionados a você se o motivo pelo qual conseguimos coletá-los (consulte a seção 2 acima) não existir mais ou se houver outra base jurídica para sua exclusão. Para itens individuais de Dados Pessoais, edite-os por meio do Painel de Privacidade ou solicite a exclusão por meio da página de suporte do Steam. Você também pode solicitar a exclusão de sua conta de usuário do Steam por meio da página de suporte do Steam.
                
                Como resultado da exclusão da sua Conta de Usuário do Steam, você perderá acesso aos serviços do Steam, incluindo a Conta de Usuário do Steam, Assinaturas e informações relacionadas aos jogos vinculados à Conta de Usuário do Steam e o acesso aos outros serviços utilizados por meio da Conta de Usuário do Steam.
                
                Permitimos que você restaure sua Conta de Usuário do Steam durante um período de carência de 30 (trinta) dias a partir do momento da exclusão da sua Conta de Usuário do Steam. Essa funcionalidade evita que você perca o acesso à sua conta por engano devido à perda das credenciais de conta ou hackers. Durante o período de suspensão, será possível finalizar e outras atividades financeiras que você tenha iniciado antes de enviar a solicitação de exclusão de Conta de Usuário do Steam. Após o período de carência, os Dados Pessoais associados à sua conta serão excluídos sem prejuízo do disposto na seção 4 acima.
                
                Em alguns casos, a exclusão da sua Conta de Usuário do Steam e, portanto, dos Dados Pessoais, pode ser mais complicado. Por exemplo, se sua conta tiver uma relação comercial com a Valve devido ao seu trabalho para um desenvolvedor de jogos, você só poderá apagar a Conta de Usuário a Steam depois de transferir essa função para outro usuário ou rescindir o relacionamento comercial. Em alguns casos, considerando a complexidade e o número de visitas, o período para o apagamento de Dados Pessoais pode ser prorrogado por um período não superior a dois meses.
                
                6.4 Direito de objeção
                Quando nosso processamento dos Dados Pessoais for baseado em interesses legítimos, de acordo com o Artigo 6(1)(f) do GDPR / Seção 2.c) da presente Política de Privacidade, você tem o direito de se opor a esse processamento. Se você se opor ao processamento, deixaremos de processar seus Dados Pessoais, exceto se houver base legítima prevalecente para o processamento, conforme descrito no Artigo 21 do GDPR, especialmente se os dados forem necessários para a definição, o exercício ou a defesa de um processo judicial. Você também tem o direito de apresentar uma reivindicação em uma autoridade supervisora.
                
                6.5 Direito à restrição do processamento de seus Dados Pessoais
                Você tem o direito de obter restrição de processamento de seus Dados Pessoais nas condições estabelecidas no artigo 18 do GDPR.
                
                6.6 Direito à portabilidade de Dados Pessoais
                Você tem o direito de receber seus Dados Pessoais em um formato estruturado, comumente usado e legível por máquina e tem o direito de transmitir esses dados para outro controlador sob as condições estabelecidas no artigo 20 do GDPR. A Valve disponibiliza seus Dados Pessoais em formato HTML estruturado por meio do Painel de Privacidade, conforme descrito acima.
                
                6.7 Direito ao controle post-mortem de seus Dados Pessoais
                Se a legislação francesa de proteção de dados for aplicável a você, você tem o direito de estabelecer diretrizes para a preservação, a exclusão e a transmissão de Dados Pessoais após a sua morte, em conformidade com o artigo 40-1 da Lei nº 78-17 de 6 de Janeiro de 1978 sobre Informação, Tecnologia, Arquivos de Dados e Liberdades Civis.
                
                6.8 Arbitragem
                Se a Valve não resolver quaisquer supostas violações dos Princípios por qualquer outro mecanismo da DPF ou pelos seus direitos sob esta seção, você tem, em concordância com os requisitos do Anexo I da DPF, a possibilidade de invocar arbitragem vinculativa diante do Painel da Estrutura de Privacidade de Dados UE-EUA.
                
                7. Crianças
                
                A idade mínima para criar uma Conta de Usuário do Steam é 13 anos. A Valve não coletará intencionalmente Dados Pessoais de crianças abaixo desta idade. Quando alguns países requerem uma idade superior para o consentimento de coleta de Dados Pessoais, é necessária a autorização dos pais para que uma Conta de Usuário do Steam seja criada e os Dados Pessoais coletados sejam associados a ela. A Valve incentiva os pais a instruírem seus filhos a nunca compartilharem informações pessoais on-line.
                
                8. Informações de contato
                
                Você pode entrar em contato diretamente com o departamento de proteção de dados da Valve no endereço abaixo.
                
                Nós analisamos qualquer solicitação enviada por e-mail, mas, a fim de evitar fraude, assédio e roubo de identidade, a única maneira de acessar, corrigir ou apagar seus dados é acessando sua Conta de Usuário do Steam em http://help.steampowered.com e selecionando os itens do menu -> Minha conta -> Visualizar dados da conta.
                
                Em conformidade com a EU-U.S. DPF, a Extensão do RU da EU-U.S. DPF e da Swiss-U.S. DPF, a Valve assume o compromisso de resolver queixas relacionadas aos Princípios da DPF sobre a nossa coleta e uso das suas informações pessoais. Indivíduos da UE, RU e Suíça com questionamentos ou queixas no que diz respeito ao nosso manuseio de dados pessoais recebidos em conformidade com a EU-U.S. DPF, a Extensão do RU à EU-U.S. DPF e a Swiss-U.S. DPF devem, primeiro, entrar em contato com a Valve em:
                
                Valve Corporation
                Att. Data Protection officer
                P.O. Box 1688
                Bellevue, WA 98009
                
                Representante da UE e Suíça para questões de proteção de dados:
                
                Valve GmbH
                Att. Legal
                Rödingsmarkt 9
                D-20459 Hamburg
                Germany
                
                Representante do Reino Unido para questões de proteção de dados:
                
                RIVACY Ltd.
                71, Warriner Gardens, Unit G1/G2
                London, SW11 4DX
                United Kingdom
                
                9. Informações adicionais para usuários do Espaço Econômico Europeu, Reino Unido e Suíça
                
                Como uma empresa sediada nos EUA que opera um serviço de jogos em todo o mundo, podemos transferir seus dados pessoais para fora do Espaço Econômico Europeu ou do Reino Unido. Nesse caso, tomamos medidas adicionais para garantir que seus dados pessoais sejam protegidos por salvaguardas legais apropriadas e que sejam tratados com segurança e de acordo com esta Política de Privacidade. A este respeito, a Valve implementou medidas contratuais e organizacionais apropriadas para garantir a confidencialidade, a segurança e a integridade dos dados do usuário em conexão com sua coleta, processamento e transferência. As medidas que tomamos incluem, entre outras coisas:
                ° Minimização da coleta de dados; em particular a possibilidade de criar e operar contas anônimas.
                ° Pseudonimização de dados.
                ° Criptografia-padrão do setor.
                ° Fornecimento de acesso a dados com base na necessidade de conhecimento.
                ° A utilização de Cláusulas Contratuais Padrão em sua versão em vigor e aprovada pela Comissão Europeia e pela UK ICO para salvaguardar as transferências.
                ° Certificação e participação na DPF, definida na Lista da DPF, disponível em https://www.dataprivacyframework.gov/s/participant-search.
                
                Em conformidade com a EU-U.S. DPF, a Extensão do RU da EU-U.S. DPF e da Swiss-U.S. DPF, a Valve assume o compromisso, sem cobrança ao indivíduo afetado, de colaborar e agir em conformidade, respectivamente, com as orientações do painel estabelecido pelas autoridades de proteção de dados da UE (DPAs), do Gabinete do Comissário da Informação do RU (ICO), da Autoridade Regulatória de Gibraltar (GRA) e do Comissário Federal da Informação e da Proteção de Dados da Suíça (FDPIC) no que diz respeito a queixas não solucionadas relacionadas ao nosso manuseio de dados pessoais recebidos em conformidade com a EU-U.S. DPF, a Extensão do RU à EU-U.S. DPF e a Swiss-U.S. DPF. Os endereços de cada autoridade encontram-se relacionados abaixo.
                ° DPAs da UE: https://edpb.europa.eu/about-edpb/about-edpb/members_en
                ° ICO do RU: https://ico.org.uk/for-the-public/
                ° GRA: https://www.gra.gi/data-protection
                ° FDPIC: https://www.edoeb.admin.ch/edoeb/home.html
                
                A Federal Trade Commission tem jurisdição sobre a conformidade da Valve com a Estrutura de Privacidade de Dados UE-EUA (EU-U.S. DPF), a Extensão do RU da EU-U.S. DPF e a Estrutura de Privacidade de Dados Suíça-EUA (Swiss-U.S. DPF).
                
                10. Informações adicionais para usuários da Califórnia
                
                A CCPA concede aos residentes da Califórnia determinados direitos de privacidade em relação aos Dados Pessoais que coletamos. Temos o compromisso de respeitar esses direitos e cumprir a CCPA. O texto a seguir explica esses direitos e as práticas da Valve com relação a eles.
                
                Direito de saber. Sob os termos da CCPA, você tem o direito de solicitar que revelemos a você quais Dados Pessoais coletamos, usamos, divulgamos e vendemos.
                
                Direito de solicitar exclusão. Você também tem o direito de solicitar a exclusão de Dados Pessoais que estejam em nossa posse, sujeitos a determinadas exceções. Observe que sua solicitação de exclusão de dados pode afetar seu uso do serviço do Steam em alguns casos, e podemos recusar a exclusão de informações por motivos estabelecidos nesta Política de Privacidade ou conforme permitido pelos termos da CCPA.
                
                Outros direitos. A CCPA também concede aos residentes da Califórnia o direito de não participar da venda de seus Dados Pessoais. Conforme descrito na seção 5, não vendemos Dados Pessoais e não o fizemos nos últimos 12 meses. Você também tem o direito de receber um aviso de nossas práticas na coleta de seus Dados Pessoais ou antes dela. Finalmente, você tem o direito de não ser discriminado por exercer seus direitos sob os termos da CCPA.
                
                Exercício de seus direitos. O principal meio de acessar, gerenciar ou excluir seus Dados Pessoais é através do Painel de Privacidade, conforme descrito na seção 6 desta Política. Os clientes também podem excluir sua Conta do Steam e os Dados Pessoais associados, conforme descrito na seção 6.3 desta Política de Privacidade. Se você não conseguir acessar ou excluir dados por meio do Painel de Privacidade, também poderá entrar em contato conosco com uma solicitação para exercer esses direitos usando o formulário em https://help.steampowered.com/en/wizard/HelpAccountDataQuestion. Para verificar sua identidade, você precisará fazer login com sua Conta de Usuário do Steam para usar o formulário. Por fim, você pode entrar em contato conosco com uma solicitação pelo e-mail questions@valvesoftware.com, no entanto, antes de fornecer acesso ou excluir quaisquer Dados Pessoais, com base em uma solicitação recebida por e-mail, precisaremos verificar sua identidade utilizando o processo de "Comprovação de Titularidade" descrito em https://support.steampowered.com/kb_article.php?ref=2268-EAFZ-9762.
                
                Você pode designar, por escrito ou por meio de um procurador, um agente autorizado a fazer solicitações em seu nome para exercer seus direitos sob os termos da CCPA. Antes de aceitar tal solicitação de um agente, exigiremos que o mesmo forneça a comprovação de que você o autorizou a agir em seu nome, e talvez seja necessário que você confirme sua identidade diretamente conosco.
                
                Categorias, fontes, finalidades e destinatários dos dados que coletamos. Nos últimos 12 meses, coletamos as categorias de Dados Pessoais descritas na seção 3 desta Política de Privacidade. As fontes das quais coletamos Dados Pessoais e as finalidades para as quais coletamos e processamos esses dados estão descritas nas seções 2 e 3. Nos últimos 12 meses, divulgamos para fins comerciais cada uma das categorias de Dados Pessoais com as categorias de terceiros conforme descritas na seção 5.
                Data da revisão: 14 de fevereiro de 2024
                Feedback de privacidade</span>
            </div>
    </main>
    <footer>
        <center><p>&copy; 2024 Paradise Game. Todos os direitos reservados. Todas as marcas são propriedade dos seus respectivos donos nos EUA e em outros países. <br>
            IVA incluso em todos os preços onde aplicável. <a href="index.php">home</a>   | <a href="termos_de_servico.php">Termos de Serviço</a>  | <a href="contato.php">Contato</a>   
            </p></center>
    </footer>
</body>
</html>
