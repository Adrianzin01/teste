<?php
session_start();

// Conexão com o banco de dados
$conn = new mysqli("localhost", "root", "", "usuarios_db");

// Verifica conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT); // Criptografar senha

    // Inserir dados no banco
    $sql = "INSERT INTO usuarios (nome, email, senha) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $nome, $email, $senha);

    if ($stmt->execute()) {
        // Inicia a sessão e armazena o ID do usuário
        $_SESSION['usuario_id'] = $conn->insert_id;
        $_SESSION['usuario_nome'] = $nome;

        // Redireciona para a página de perfil
        header("Location: perfil.php");
        exit;
    } else {
        echo "Erro ao cadastrar: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style_login.css">
    <title>Cadastro</title>
    <style>
        body{
    font-family: Arial, Helvetica, sans-serif;
    background-color: aliceblue;
}
div {
    background-color: rgb(0, 0, 0);
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%,-50%);
    padding: 80px;
    border-radius: 15px;
    color: aliceblue;
}
input{
    padding: 15px;
    border: none;
    outline: none;
    font-size: 15px;
}
button{
    background-color: dodgerblue;
    border: none;
    padding: 15px;
    width: 100%;
    border-radius: 10px;
    color: aliceblue;
    font-size: 15px;
}
button:hover{
    background-color: deepskyblue;
}
    </style>
</head>
<body>
    <h1>Cadastro</h1>
    <form action="cadastro.php" method="POST">
        <label for="nome">Nome:</label>
        <input type="text" id="nome" name="nome" required><br><br>

        <label for="email">E-mail:</label>
        <input type="email" id="email" name="email" required><br><br>

        <label for="senha">Senha:</label>
        <input type="password" id="senha" name="senha" required><br><br>

        <button type="submit">Cadastrar</button>
    </form>
</body>
</html>
