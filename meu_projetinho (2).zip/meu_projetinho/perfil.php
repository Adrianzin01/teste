<?php
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
    header("Location: login.php");
    exit;
}

// Conexão com o banco de dados
$conn = new mysqli("localhost", "root", "", "usuarios_db");

// Verifica conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Consulta para pegar os dados do usuário logado
$sql = "SELECT nome, email FROM usuarios WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $_SESSION['usuario_id']);
$stmt->execute();
$result = $stmt->get_result();
$usuario = $result->fetch_assoc();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Perfil</title>
</head>
<body>
    <h1>Perfil de <?php echo $_SESSION['usuario_nome']; ?></h1>
    
    <p><strong>Nome:</strong> <?php echo $usuario['nome']; ?></p>
    <p><strong>E-mail:</strong> <?php echo $usuario['email']; ?></p>

    <a href="editar.php">Editar Perfil</a><br>
    <a href="excluir.php">Excluir Conta</a><br>
    <a href="logout.php">Sair</a>
</body>
</html>
