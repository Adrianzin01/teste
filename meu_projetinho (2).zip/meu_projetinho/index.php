<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="script.js"></script>
    <link rel="stylesheet" href="style.css">
    <title>Paradise Game</title>
    <header>
        <h1>Catálogo de Jogos Online</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="contato.php">Contato</a></li>
                <li><a href="termos_de_servico.php">Termos de Serviço</a></li>
                <li><a href="politica_privacidade.php">Política de privacidade</a></li>
            </ul>
        </nav>
        <div class="cadastro">
            <a href="cadastro.php"><button>Cadastrar</button></a>
        </div>
        <div class="login">
            <a href="login.php"><button>Login</button></a>
        </div>
    </header>
<div class="container">
    <!-- Categoria: Ação -->
    <div class="category">
        <h2>Ação</h2>
        <div class="game-grid">
            <div class="game">
                <img src="img/DOOM_Eternal_capa.jpg" alt="DOOM Eternal">
                <h3>DOOM Eternal</h3>
                <p class="description">Um jogo de tiro em primeira pessoa intenso, onde você deve enfrentar hordas de demônios.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 89,90</div>
                <button><a href=""></a>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/DOOM_Eternal_capa.jpg" alt="DOOM Eternal">
                <h3>DOOM Eternal</h3>
                <p class="description">Um jogo de tiro em primeira pessoa intenso, onde você deve enfrentar hordas de demônios.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 89,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Devil_May_Cry_5_capa.jpg" alt="Devil May Cry 5">
                <h3>Devil May Cry 5</h3>
                <p class="description">A aventura de Dante e seus amigos retorna com combate visceral e visuais impressionantes.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 99,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Far_Cry_6_capa.jpg" alt="Far Cry 6">
                <h3>Far Cry 6</h3>
                <p class="description">Aventure-se em uma ilha tropical como guerrilheiro lutando contra um regime opressivo.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 109,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Hitman_3_capa.jpg" alt="Hitman 3">
                <h3>Hitman 3</h3>
                <p class="description">Conclua a trilogia de Agente 47 com assassinatos criativos em locais deslumbrantes.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 89,90</div>
                <button>Comprar Agora</button>
            </div>
            <!-- Segunda fileira -->
            <div class="game">
                <img src="img/Resident_Evil_Village_capa.jpg" alt="Resident Evil Village">
                <h3>Resident Evil Village</h3>
                <p class="description">Explore uma vila sombria enquanto busca por sua filha em uma atmosfera aterrorizante.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 99,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/DOOM_Eternal_capa.jpg" alt="DOOM Eternal">
                <h3>DOOM Eternal</h3>
                <p class="description">Um jogo de tiro em primeira pessoa intenso, onde você deve enfrentar hordas de demônios.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 89,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Assassins_Creed_Valhalla_capa.jpg" alt="Assassin's Creed Valhalla">
                <h3>Assassin's Creed Valhalla</h3>
                <p class="description">Viva como um vikings em uma história épica de conquista e exploração na Inglaterra medieval.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 109,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Just_Cause_4_capa.jpg" alt="Just Cause 4">
                <h3>Just Cause 4</h3>
                <p class="description">Caos absoluto em um mundo aberto, com possibilidades infinitas para destruição.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 89,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Borderlands_3_capa.jpg" alt="Borderlands 3">
                <h3>Borderlands 3</h3>
                <p class="description">Um shooter looter com um estilo único e humor, repleto de ação e personagens excêntricos.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 99,90</div>
                <button>Comprar Agora</button>
            </div>
            <!-- Terceira fileira -->
            <div class="game">
                <img src="img/Call_of_Duty_Modern_Warfare_capa.jpg" alt="Call of Duty: Modern Warfare">
                <h3>Call of Duty: Modern Warfare</h3>
                <p class="description">Um dos melhores jogos de tiro em primeira pessoa, focado em uma narrativa intensa e multiplayer emocionante.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 129,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Call_of_Duty_Modern_Warfare_capa.jpg" alt="Call of Duty: Modern Warfare">
                <h3>Call of Duty: Modern Warfare</h3>
                <p class="description">Um dos melhores jogos de tiro em primeira pessoa, focado em uma narrativa intensa e multiplayer emocionante.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 129,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Overwatch_2_capa.jpg" alt="Overwatch 2">
                <h3>Overwatch 2</h3>
                <p class="description">Um jogo de tiro em equipe que combina heróis únicos com habilidades especiais.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 69,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Ghost_of_Tsushima_capa.jpg" alt="Ghost of Tsushima">
                <h3>Ghost of Tsushima</h3>
                <p class="description">Explore um Japão feudal deslumbrante enquanto você luta como o último samurai.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 129,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Metal_Gear_Solid_V_capa.jpg" alt="Metal Gear Solid V: The Phantom Pain">
                <h3>Metal Gear Solid V: The Phantom Pain</h3>
                <p class="description">Uma experiência de ação furtiva com uma narrativa rica e mundo aberto para explorar.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 99,90</div>
                <button>Comprar Agora</button>
            </div>
        </div>
    </div>

    <!-- Categoria: Aventura -->
    <div class="category">
        <h2>Aventura</h2>
        <div class="game-grid">
            <div class="game">
                <img src="img/Horizon_Zero_Dawn_capa.jpg" alt="Horizon Zero Dawn">
                <h3>Horizon Zero Dawn</h3>
                <p class="description">Mergulhe em um mundo pós-apocalíptico habitado por máquinas, com uma história envolvente.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 99,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Horizon_Zero_Dawn_capa.jpg" alt="Horizon Zero Dawn">
                <h3>Horizon Zero Dawn</h3>
                <p class="description">Mergulhe em um mundo pós-apocalíptico habitado por máquinas, com uma história envolvente.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 99,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/No_Man's_Sky_capa.jpg" alt="No Man's Sky">
                <h3>No Man's Sky</h3>
                <p class="description">Explore um universo infinito gerado proceduralmente, cheio de planetas e vida alienígena.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 99,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Firewatch_capa.jpg" alt="Firewatch">
                <h3>Firewatch</h3>
                <p class="description">Uma experiência narrativa em primeira pessoa, explorando temas de solidão e conexão.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 69,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Untitled_Goose_Game_capa.jpg" alt="Untitled Goose Game">
                <h3>Untitled Goose Game</h3>
                <p class="description">Divirta-se como um ganso travesso em um jogo de quebra-cabeça e aventura.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 59,90</div>
                <button>Comprar Agora</button>
            </div>
            <!-- Segunda fileira -->
            <div class="game">
                <img src="img/Outer_Wilds_capa.jpg" alt="Outer Wilds">
                <h3>Outer Wilds</h3>
                <p class="description">Uma experiência única de exploração espacial e descoberta, onde cada ciclo de tempo é importante.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 89,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Horizon_Zero_Dawn_capa.jpg" alt="Horizon Zero Dawn">
                <h3>Horizon Zero Dawn</h3>
                <p class="description">Mergulhe em um mundo pós-apocalíptico habitado por máquinas, com uma história envolvente.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 99,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Spiritfarer_capa.jpg" alt="Spiritfarer">
                <h3>Spiritfarer</h3>
                <p class="description">Um jogo de gerenciamento e aventura sobre a vida e a morte, onde você guia almas para o além.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 59,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Ratchet_and_Clank_Rift_Apart_capa.jpg" alt="Ratchet & Clank: Rift Apart">
                <h3>Ratchet & Clank: Rift Apart</h3>
                <p class="description">Ação e aventura em um mundo colorido com mecânicas de quebra de dimensões.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 79,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Gris_capa.jpg" alt="Gris">
                <h3>Gris</h3>
                <p class="description">Um jogo de plataforma visualmente impressionante com uma narrativa sobre superação e crescimento.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 39,90</div>
                <button>Comprar Agora</button>
            </div>
            <!-- Terceira fileira -->
            <div class="game">
                <img src="img/Celeste_capa.jpg" alt="Celeste">
                <h3>Celeste</h3>
                <p class="description">Uma plataforma desafiadora que conta a história de uma jovem em sua jornada para escalar uma montanha.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 49,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Horizon_Zero_Dawn_capa.jpg" alt="Horizon Zero Dawn">
                <h3>Horizon Zero Dawn</h3>
                <p class="description">Mergulhe em um mundo pós-apocalíptico habitado por máquinas, com uma história envolvente.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 99,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/The_Outer_Worlds_capa.jpg" alt="The Outer Worlds">
                <h3>The Outer Worlds</h3>
                <p class="description">Um RPG de ação que combina humor e escolhas significativas em um universo de ficção científica.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 99,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Assassin's_Creed_Odyssey_capa.jpg" alt="Assassin's Creed Odyssey">
                <h3>Assassin's Creed Odyssey</h3>
                <p class="description">Viaje pela Grécia antiga e torne-se um herói em uma das maiores aventuras da série.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 99,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Control_capa.jpg" alt="Control">
                <h3>Control</h3>
                <p class="description">Um jogo de ação e aventura em um mundo surreal, onde você explora uma agência secreta.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 79,90</div>
                <button>Comprar Agora</button>
            </div>
        </div>
    </div>

    <!-- Categoria: RPG -->
    <div class="category">
        <h2>RPG</h2>
        <div class="game-grid">
            <div class="game">
                <img src="img/The_Witcher_3_capa.jpg" alt="The Witcher 3: Wild Hunt">
                <h3>The Witcher 3: Wild Hunt</h3>
                <p class="description">Explore um mundo vasto cheio de segredos enquanto busca pela sua filha adotiva em uma narrativa rica.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 159,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/The_Witcher_3_capa.jpg" alt="The Witcher 3: Wild Hunt">
                <h3>The Witcher 3: Wild Hunt</h3>
                <p class="description">Explore um mundo vasto cheio de segredos enquanto busca pela sua filha adotiva em uma narrativa rica.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 159,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Elden_Ring_capa.jpg" alt="Elden Ring">
                <h3>Elden Ring</h3>
                <p class="description">Mergulhe em um mundo aberto e expansivo, onde a exploração e a luta são essenciais para sua sobrevivência.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 99,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Monster_Hunter_World_capa.jpg" alt="Monster Hunter: World">
                <h3>Monster Hunter: World</h3>
                <p class="description">Entre em um mundo vibrante e dinâmico, onde você pode caçar monstros gigantes e forjar armas poderosas.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 89,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/World_of_Warcraft_capa.jpg" alt="World of Warcraft">
                <h3>World of Warcraft</h3>
                <p class="description">Um dos MMORPGs mais populares, onde você pode explorar um vasto mundo, completar missões e interagir com outros jogadores.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 69,90</div>
                <button>Comprar Agora</button>
            </div>
            <!-- Segunda fileira -->
            <div class="game">
                <img src="img/Dragon_Age_Inquisition_capa.jpg" alt="Dragon Age: Inquisition">
                <h3>Dragon Age: Inquisition</h3>
                <p class="description">Lidere uma equipe de heróis em uma batalha épica contra forças malignas e descubra segredos do seu mundo.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 89,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/The_Witcher_3_capa.jpg" alt="The Witcher 3: Wild Hunt">
                <h3>The Witcher 3: Wild Hunt</h3>
                <p class="description">Explore um mundo vasto cheio de segredos enquanto busca pela sua filha adotiva em uma narrativa rica.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 159,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Final_Fantasy_VII_Remake_capa.jpg" alt="Final Fantasy VII Remake">
                <h3>Final Fantasy VII Remake</h3>
                <p class="description">Reviva uma das maiores histórias de RPG com gráficos e jogabilidade renovados.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 129,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Persona_5_capa.jpg" alt="Persona 5">
                <h3>Persona 5</h3>
                <p class="description">Experimente a vida de um estudante e um ladrão de almas enquanto explora o mundo dos sonhos.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 89,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Sekiro_Shadows_Die_Twice_capa.jpg" alt="Sekiro: Shadows Die Twice">
                <h3>Sekiro: Shadows Die Twice</h3>
                <p class="description">Um jogo desafiador que combina furtividade, combate e exploração em um Japão feudal devastado.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 89,90</div>
                <button>Comprar Agora</button>
            </div>
            <!-- Terceira fileira -->
            <div class="game">
                <img src="img/Divinity_Original_Sin_2_capa.jpg" alt="Divinity: Original Sin 2">
                <h3>Divinity: Original Sin 2</h3>
                <p class="description">Um RPG de estratégia com uma narrativa rica e combate tático profundo.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 89,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/The_Witcher_3_capa.jpg" alt="The Witcher 3: Wild Hunt">
                <h3>The Witcher 3: Wild Hunt</h3>
                <p class="description">Explore um mundo vasto cheio de segredos enquanto busca pela sua filha adotiva em uma narrativa rica.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 159,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Baldurs_Gate_3_capa.jpg" alt="Baldur's Gate 3">
                <h3>Baldur's Gate 3</h3>
                <p class="description">Um retorno à famosa série de RPG, onde suas escolhas moldam a história e o mundo ao seu redor.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 139,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Monster_Hunter_Rise_capa.jpg" alt="Monster Hunter Rise">
                <h3>Monster Hunter Rise</h3>
                <p class="description">Uma nova aventura na série, com novos monstros e mecânicas de jogo.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 89,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Octopath_Traveler_capa.jpg" alt="Octopath Traveler">
                <h3>Octopath Traveler</h3>
                <p class="description">Um RPG clássico com um estilo visual único e uma narrativa envolvente.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 79,90</div>
                <button>Comprar Agora</button>
            </div>
        </div>
    </div>

    <!-- Categoria: Simulação -->
    <div class="category">
        <h2>Simulação</h2>
        <div class="game-grid">
            <div class="game">
                <img src="img/The_Sims_4_capa.jpg" alt="The Sims 4">
                <h3>The Sims 4</h3>
                <p class="description">Crie e controle pessoas em um mundo aberto onde tudo é possível.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 89,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
            <img src="img/The_Sims_4_capa.jpg" alt="The Sims 4">
                <h3>The Sims 4</h3>
                <p class="description">Crie e controle pessoas em um mundo aberto onde tudo é possível.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 89,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Cities_Skylines_capa.jpg" alt="Cities: Skylines">
                <h3>Cities: Skylines</h3>
                <p class="description">Construa e gerencie sua própria cidade em um jogo de simulação desafiador.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 79,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Planet_Coaster_capa.jpg" alt="Planet Coaster">
                <h3>Planet Coaster</h3>
                <p class="description">Crie e gerencie seu próprio parque de diversões com montanhas-russas emocionantes.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 89,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Flight_Simulator_2020_capa.jpg" alt="Microsoft Flight Simulator">
                <h3>Microsoft Flight Simulator</h3>
                <p class="description">Experimente voar como nunca antes, com gráficos impressionantes e um mundo realista.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 249,90</div>
                <button>Comprar Agora</button>
            </div>
            <!-- Segunda fileira -->
            <div class="game">
                <img src="img/Animal_Crossing_New_Horizons_capa.jpg" alt="Animal Crossing: New Horizons">
                <h3>Animal Crossing: New Horizons</h3>
                <p class="description">Crie sua própria ilha dos sonhos enquanto interage com adoráveis animais antropomórficos.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 299,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Animal_Crossing_New_Horizons_capa.jpg" alt="Animal Crossing: New Horizons">
                <h3>Animal Crossing: New Horizons</h3>
                <p class="description">Crie sua própria ilha dos sonhos enquanto interage com adoráveis animais antropomórficos.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 299,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Stardew_Valley_capa.jpg" alt="Stardew Valley">
                <h3>Stardew Valley</h3>
                <p class="description">Viva a vida no campo, cultive sua fazenda e faça amigos na aldeia.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 49,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Factorio_capa.jpg" alt="Factorio">
                <h3>Factorio</h3>
                <p class="description">Construa e otimize fábricas enquanto luta contra alienígenas em um mundo alienígena.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 69,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Prison_Architect_capa.jpg" alt="Prison Architect">
                <h3>Prison Architect</h3>
                <p class="description">Construa e gerencie sua própria prisão, lidando com os desafios diários.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 79,90</div>
                <button>Comprar Agora</button>
            </div>
            <!-- Terceira fileira -->
            <div class="game">
                <img src="img/House_Flipper_capa.jpg" alt="House Flipper">
                <h3>House Flipper</h3>
                <p class="description">Compre, reforme e venda casas para criar o lar dos seus sonhos.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 69,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Animal_Crossing_New_Horizons_capa.jpg" alt="Animal Crossing: New Horizons">
                <h3>Animal Crossing: New Horizons</h3>
                <p class="description">Crie sua própria ilha dos sonhos enquanto interage com adoráveis animais antropomórficos.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 299,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Two_Point_Hospital_capa.jpg" alt="Two Point Hospital">
                <h3>Two Point Hospital</h3>
                <p class="description">Construa e gerencie um hospital, tratando doenças peculiares com humor.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 69,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Planet_Fallout_capa.jpg" alt="Fallout Shelter">
                <h3>Fallout Shelter</h3>
                <p class="description">Construa e gerencie um abrigo nuclear, cuidando de seus moradores.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 49,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/SimCity_2013_capa.jpg" alt="SimCity">
                <h3>SimCity</h3>
                <p class="description">Crie e gerencie sua própria cidade, enfrentando desafios urbanos e econômicos.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 99,90</div>
                <button>Comprar Agora</button>
            </div>
        </div>
    </div>

    <!-- Categoria: Aventura -->
    <div class="category">
        <h2>Aventura</h2>
        <div class="game-grid">
            <div class="game">
                <img src="img/The_Legend_of_Zelda_Breath_of_the_Wild_capa.jpg" alt="The Legend of Zelda: Breath of the Wild">
                <h3>The Legend of Zelda: Breath of the Wild</h3>
                <p class="description">Explore um vasto mundo aberto enquanto enfrenta inimigos e resolve quebra-cabeças.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 299,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/The_Legend_of_Zelda_Breath_of_the_Wild_capa.jpg" alt="The Legend of Zelda: Breath of the Wild">
                <h3>The Legend of Zelda: Breath of the Wild</h3>
                <p class="description">Explore um vasto mundo aberto enquanto enfrenta inimigos e resolve quebra-cabeças.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 299,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Red_Dead_Redemption_2_capa.jpg" alt="Red Dead Redemption 2">
                <h3>Red Dead Redemption 2</h3>
                <p class="description">Uma narrativa épica ambientada no Velho Oeste, onde você se junta a uma gangue de fora da lei.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 199,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Assassin's_Creed_Valhalla_capa.jpg" alt="Assassin's Creed Valhalla">
                <h3>Assassin's Creed Valhalla</h3>
                <p class="description">Viva como um vikingo em uma narrativa rica em ação, aventura e exploração.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 199,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Ghost_of_Tsushima_capa.jpg" alt="Ghost of Tsushima">
                <h3>Ghost of Tsushima</h3>
                <p class="description">Experimente o Japão feudal como um samurai em busca de libertar sua ilha de invasores.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 159,90</div>
                <button>Comprar Agora</button>
            </div>
            <!-- Segunda fileira -->
            <div class="game">
                <img src="img/Spider-Man_Miles_Morales_capa.jpg" alt="Spider-Man: Miles Morales">
                <h3>Spider-Man: Miles Morales</h3>
                <p class="description">Acompanhe Miles em sua jornada como o novo Homem-Aranha em Nova York.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 179,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/The_Legend_of_Zelda_Breath_of_the_Wild_capa.jpg" alt="The Legend of Zelda: Breath of the Wild">
                <h3>The Legend of Zelda: Breath of the Wild</h3>
                <p class="description">Explore um vasto mundo aberto enquanto enfrenta inimigos e resolve quebra-cabeças.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 299,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Control_capa.jpg" alt="Control">
                <h3>Control</h3>
                <p class="description">Um jogo de ação e aventura em um mundo surreal, onde você explora uma agência secreta.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 79,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Batman_Arkham_Knight_capa.jpg" alt="Batman: Arkham Knight">
                <h3>Batman: Arkham Knight</h3>
                <p class="description">Junte-se ao Cavaleiro das Trevas em sua luta contra o crime em Gotham.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 79,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Detroit_Become_Human_capa.jpg" alt="Detroit: Become Human">
                <h3>Detroit: Become Human</h3>
                <p class="description">Uma narrativa interativa que explora a vida de androides em um futuro próximo.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 99,90</div>
                <button>Comprar Agora</button>
            </div>
            <!-- Terceira fileira -->
            <div class="game">
                <img src="img/Death_Stranding_capa.jpg" alt="Death Stranding">
                <h3>Death Stranding</h3>
                <p class="description">Uma experiência única que combina aventura e narrativa em um mundo pós-apocalíptico.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 99,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/The_Legend_of_Zelda_Breath_of_the_Wild_capa.jpg" alt="The Legend of Zelda: Breath of the Wild">
                <h3>The Legend of Zelda: Breath of the Wild</h3>
                <p class="description">Explore um vasto mundo aberto enquanto enfrenta inimigos e resolve quebra-cabeças.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 299,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Sekiro_Shadows_Die_Twice_capa.jpg" alt="Sekiro: Shadows Die Twice">
                <h3>Sekiro: Shadows Die Twice</h3>
                <p class="description">Um jogo desafiador que combina furtividade, combate e exploração em um Japão feudal devastado.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 89,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/God_of_War_capa.jpg" alt="God of War">
                <h3>God of War</h3>
                <p class="description">Uma reimaginação da clássica saga, onde Kratos deve enfrentar deuses e mitos nórdicos.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 159,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Final_Fantasy_XV_capa.jpg" alt="Final Fantasy XV">
                <h3>Final Fantasy XV</h3>
                <p class="description">Acompanhe a jornada de Noctis e seus amigos em um mundo de fantasia cheio de aventuras.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 99,90</div>
                <button>Comprar Agora</button>
            </div>
        </div>
    </div>

    <!-- Categoria: Estratégia -->
    <div class="category">
        <h2>Estratégia</h2>
        <div class="game-grid">
            <div class="game">
                <img src="img/Civilization_VI_capa.jpg" alt="Sid Meier's Civilization VI">
                <h3>Sid Meier's Civilization VI</h3>
                <p class="description">Construa um império que resista ao teste do tempo, desde a Idade da Pedra até o futuro.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 199,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Civilization_VI_capa.jpg" alt="Sid Meier's Civilization VI">
                <h3>Sid Meier's Civilization VI</h3>
                <p class="description">Construa um império que resista ao teste do tempo, desde a Idade da Pedra até o futuro.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 199,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Starcraft_II_capa.jpg" alt="StarCraft II">
                <h3>StarCraft II</h3>
                <p class="description">Lidere suas tropas em batalhas épicas em um universo de ficção científica.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 89,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Total_War_Three_Kingdoms_capa.jpg" alt="Total War: Three Kingdoms">
                <h3>Total War: Three Kingdoms</h3>
                <p class="description">Experimente a guerra e a diplomacia na China antiga em um jogo de estratégia profundo.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 159,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/XCOM_2_capa.jpg" alt="XCOM 2">
                <h3>XCOM 2</h3>
                <p class="description">Lute contra uma invasão alienígena em um jogo de estratégia por turnos desafiador.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 89,90</div>
                <button>Comprar Agora</button>
            </div>
            <!-- Segunda fileira -->
            <div class="game">
                <img src="img/Warcraft_III_Reforged_capa.jpg" alt="Warcraft III: Reforged">
                <h3>Warcraft III: Reforged</h3>
                <p class="description">Reviva um clássico da estratégia em tempo real com gráficos atualizados e novas mecânicas.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 89,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Civilization_VI_capa.jpg" alt="Sid Meier's Civilization VI">
                <h3>Sid Meier's Civilization VI</h3>
                <p class="description">Construa um império que resista ao teste do tempo, desde a Idade da Pedra até o futuro.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 199,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Crusader_Kings_III_capa.jpg" alt="Crusader Kings III">
                <h3>Crusader Kings III</h3>
                <p class="description">Construa sua dinastia e governe seu reino em um mundo medieval complexo.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 199,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Anno_1800_capa.jpg" alt="Anno 1800">
                <h3>Anno 1800</h3>
                <p class="description">Construa e gerencie cidades na era industrial em um jogo de estratégia complexo.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 199,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Company_of_Heroes_3_capa.jpg" alt="Company of Heroes 3">
                <h3>Company of Heroes 3</h3>
                <p class="description">Um jogo de estratégia em tempo real ambientado na Segunda Guerra Mundial, com novas mecânicas.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 159,90</div>
                <button>Comprar Agora</button>
            </div>
            <!-- Terceira fileira -->
            <div class="game">
                <img src="img/Warhammer_40K_Chaos_Gate_capa.jpg" alt="Warhammer 40,000: Chaos Gate">
                <h3>Warhammer 40,000: Chaos Gate</h3>
                <p class="description">Uma estratégia por turnos ambientada no universo Warhammer 40k, onde você combate forças do Caos.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 89,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Civilization_VI_capa.jpg" alt="Sid Meier's Civilization VI">
                <h3>Sid Meier's Civilization VI</h3>
                <p class="description">Construa um império que resista ao teste do tempo, desde a Idade da Pedra até o futuro.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 199,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Cities_Skylines_capa.jpg" alt="Cities: Skylines">
                <h3>Cities: Skylines</h3>
                <p class="description">Construa e gerencie sua própria cidade em um jogo de simulação desafiador.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 79,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Fallout_4_capa.jpg" alt="Fallout 4">
                <h3>Fallout 4</h3>
                <p class="description">Sobreviva em um mundo pós-apocalíptico, tomando decisões que moldam sua história.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 89,90</div>
                <button>Comprar Agora</button>
            </div>
            <div class="game">
                <img src="img/Endless_Space_2_capa.jpg" alt="Endless Space 2">
                <h3>Endless Space 2</h3>
                <p class="description">Construa um império espacial em um jogo de estratégia por turnos profundo e envolvente.</p>
                <button class="read-more">Ler mais</button>
                <div class="price">R$ 99,90</div>
                <button>Comprar Agora</button>
            </div>
        </div>
    </div>
</div>
<footer>
<p>&copy; 2024 Paradise Game. Todos os direitos reservados. Todas as marcas são propriedade dos seus respectivos donos nos EUA e em outros países.
    IVA incluso em todos os preços onde aplicável.  |   <a href="politica_privacidade.php">Política de Privacidade</a>  |    <a href="termos_de_servico.php">Termos de Serviço</a>  |   <a href="contato.php">Contato</a>
    </p>
</footer>
</body>
</html>